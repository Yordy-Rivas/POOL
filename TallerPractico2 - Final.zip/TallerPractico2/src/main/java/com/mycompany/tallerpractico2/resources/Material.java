package com.mycompany.tallerpractico2.resources;

public class Material {
    private int id;
    private String titulo;
    private String tipo;
    private int CategoriaId;
    private int AutorId;

    public Material() {}
    public Material(int id, String titulo, String tipo, int CategoriaId, int AutorId) {
        this.id = id;
        this.titulo = titulo;
        this.tipo = tipo;
        this.CategoriaId = CategoriaId;
        this.AutorId = AutorId;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public int getCategoriaId() { return CategoriaId; }
    public void setCategoriaId(int CategoriaId) { this.CategoriaId = CategoriaId; }

    public int getAutorId() { return AutorId; }
    public void setAutorId(int AutorId) { this.AutorId = AutorId; }
}
