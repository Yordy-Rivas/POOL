package com.mycompany.tallerpractico2;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.mycompany.tallerpractico2.resources.Material;
import com.mycompany.tallerpractico2.resources.Categoria;
import com.mycompany.tallerpractico2.resources.Autor;
import com.mycompany.tallerpractico2.util.Conexion;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/MaterialServlet")
public class MaterialServlet extends HttpServlet {

    @Override
    public void init() throws ServletException {
        System.out.println("Inicializando MaterialServlet");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        String action = request.getParameter("action");
        if (action == null) action = "listar";

        switch (action) {
            case "nuevo":
                // Pasar listas de categorias y autores al formulario
                request.setAttribute("listaCategorias", listarCategorias());
                request.setAttribute("listaAutores", listarAutores());
                request.getRequestDispatcher("/Material/formulario.jsp").forward(request, response);
                break;

            case "editar":
                int idEditar = Integer.parseInt(request.getParameter("id"));
                Material material = buscarPorId(idEditar);
                request.setAttribute("material", material);
                request.setAttribute("listaCategorias", listarCategorias());
                request.setAttribute("listaAutores", listarAutores());
                request.getRequestDispatcher("/Material/formulario.jsp").forward(request, response);
                break;

            case "eliminar":
                int idEliminar = Integer.parseInt(request.getParameter("id"));
                eliminar(idEliminar);
                response.sendRedirect("MaterialServlet?action=listar");
                break;

            case "listar":
            default:
                List<Material> lista = listar();
                request.setAttribute("listaMateriales", lista);
                request.getRequestDispatcher("/Material/lista.jsp").forward(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");
        String titulo = request.getParameter("titulo");
        String tipo = request.getParameter("tipo");

        String categoriaParam = request.getParameter("categoriaId");
        String autorParam = request.getParameter("autorId");

        int categoriaId;
        int autorId;

        try {
            if (categoriaParam == null || categoriaParam.isEmpty() ||
                autorParam == null || autorParam.isEmpty()) {
                throw new NumberFormatException("IDs vacíos");
            }

            categoriaId = Integer.parseInt(categoriaParam);
            autorId = Integer.parseInt(autorParam);

            if (categoriaId <= 0 || autorId <= 0) {
                throw new NumberFormatException("IDs deben ser positivos");
            }

        } catch (NumberFormatException e) {
            request.setAttribute("error", "Los IDs de categoría y autor deben ser números enteros positivos.");
            request.setAttribute("listaCategorias", listarCategorias());
            request.setAttribute("listaAutores", listarAutores());
            request.getRequestDispatcher("/Material/formulario.jsp").forward(request, response);
            return;
        }

        Material material = new Material();
        material.setTitulo(titulo);
        material.setTipo(tipo);
        material.setCategoriaId(categoriaId);
        material.setAutorId(autorId);

        if (id == null || id.isEmpty()) {
            insertar(material);
        } else {
            material.setId(Integer.parseInt(id));
            actualizar(material);
        }

        response.sendRedirect("MaterialServlet?action=listar");
    }

    private List<Material> listar() {
        List<Material> lista = new ArrayList<>();
        String sql = "SELECT * FROM material";

        try (Connection con = Conexion.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Material m = new Material();
                m.setId(rs.getInt("id"));
                m.setTitulo(rs.getString("titulo"));
                m.setTipo(rs.getString("tipo"));
                m.setCategoriaId(rs.getInt("id_categoria"));
                m.setAutorId(rs.getInt("id_autor"));
                lista.add(m);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    private Material buscarPorId(int id) {
        Material m = null;
        String sql = "SELECT * FROM material WHERE id=?";

        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                m = new Material();
                m.setId(rs.getInt("id"));
                m.setTitulo(rs.getString("titulo"));
                m.setTipo(rs.getString("tipo"));
                m.setCategoriaId(rs.getInt("id_categoria"));
                m.setAutorId(rs.getInt("id_autor"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return m;
    }

    private void insertar(Material material) {
        String sql = "INSERT INTO material (titulo, tipo, id_categoria, id_autor) VALUES (?, ?, ?, ?)";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, material.getTitulo());
            ps.setString(2, material.getTipo());
            ps.setInt(3, material.getCategoriaId());
            ps.setInt(4, material.getAutorId());
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void actualizar(Material material) {
        String sql = "UPDATE material SET titulo=?, tipo=?, id_categoria=?, id_autor=? WHERE id=?";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, material.getTitulo());
            ps.setString(2, material.getTipo());
            ps.setInt(3, material.getCategoriaId());
            ps.setInt(4, material.getAutorId());
            ps.setInt(5, material.getId());
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void eliminar(int idEliminar) {
        String sql = "DELETE FROM material WHERE id=?";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idEliminar);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private List<Categoria> listarCategorias() {
        List<Categoria> lista = new ArrayList<>();
        String sql = "SELECT * FROM categoria";
        try (Connection con = Conexion.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Categoria c = new Categoria();
                c.setId(rs.getInt("id"));
                c.setNombre(rs.getString("nombre"));
                lista.add(c);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    private List<Autor> listarAutores() {
        List<Autor> lista = new ArrayList<>();
        String sql = "SELECT * FROM autor";
        try (Connection con = Conexion.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Autor a = new Autor();
                a.setId(rs.getInt("id"));
                a.setNombre(rs.getString("nombre"));
                a.setNacionalidad(rs.getString("nacionalidad"));
                lista.add(a);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }
}
