package com.mycompany.tallerpractico2.resources;

public class Material {
    private int id;
    private String titulo;
    private String tipo;
    private int categoriaId;
    private int autorId;

    public Material() {}
    public Material(int id, String titulo, String tipo, int categoriaId, int autorId) {
        this.id = id;
        this.titulo = titulo;
        this.tipo = tipo;
        this.categoriaId = categoriaId;
        this.autorId = autorId;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public int getCategoriaId() { return categoriaId; }
    public void setCategoriaId(int categoriaId) { this.categoriaId = categoriaId; }

    public int getAutorId() { return autorId; }
    public void setAutorId(int autorId) { this.autorId = autorId; }
}
